package Buoi1;

public class Bai1 {

    public static void main(String[] args) {

        int age = 20;
        String name = "Nguyen Nhon Hau";

        System.out.println("Hello! I'm " + name);
        System.out.println("I'm " + age + " year old");
        System.out.println("This is my first java program");
    }
}

package Buoi1;

import java.util.Scanner;

public class Bai2 {

    public class bai2 {

        public static void main(String[] args) {
            Scanner x = new Scanner(System.in);
            System.out.print("Nhap ma sinh vien : ");
            String masv = x.nextLine();
            System.out.print("Nhap ma ho ten : ");
            String ten = x.nextLine();
            System.out.print("Nhap tuoi : ");
            byte tuoi = x.nextByte();
            System.out.print("Nhap nam sinh : ");
            int nam = x.nextInt();
            System.out.print("Nhap diem trung binh : ");
            byte diem = x.nextByte();

            x.close();
        }
    }
}

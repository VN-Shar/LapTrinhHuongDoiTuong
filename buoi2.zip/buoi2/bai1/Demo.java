package buoi2.bai1;

public class Demo {
    public static void main(String[] args) {
        DanhSachHocSinh danhSachHocSinh = new DanhSachHocSinh();
        danhSachHocSinh.nhapDanhSach();
        danhSachHocSinh.xuatDanhSach();
        danhSachHocSinh.sapXep();
        System.out.println("Sap xep");
        danhSachHocSinh.xuatDanhSach();
    }
}
